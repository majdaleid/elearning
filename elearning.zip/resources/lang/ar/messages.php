<?php
return [
    'welcome'       => 'المسج'
];
