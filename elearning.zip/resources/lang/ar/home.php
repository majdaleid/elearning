<?php
return [
'home'=>"الرئيسية",
'courses'=>"الدورات",
'pricing'=>"الأسعار",
'blog'=>"المدونة",
'login'=>"تسجيل الدخول",
'register'=>"التسجيل",
'contact'=>"الاتصال بنا"

]



 ?>
