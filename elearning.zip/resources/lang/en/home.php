<?php
return [
'home'=>"Home",
'courses'=>"courses",
'pricing'=>"pricing",
'blog'=>"blog",
'login'=>"login",
'register'=>"register",
'contact'=>"contact us"

]



 ?>
