<?php
return [
    'client_id' => 'ATxJyhRONdZ2T9UAOEu_XH0ioU7cenjykGK-zylACE-HH5s5tK586Ft9ihjTqeQ5m-cbjvsAU6x2l8Mb',
	'secret' => 'EF3MqoIGIX6UCJJFc464m9_Q7EhagMsZY45AVUXDrXDKR1jPbrVq4JVXZrO3fKI_2ftcUvQDsrWjxsQ5',
    'settings' => array(
        'mode' => 'sandbox',
        'http.ConnectionTimeOut' => 1000,
        'log.LogEnabled' => true,
        'log.FileName' => storage_path() . '/logs/paypal.log',
        'log.LogLevel' => 'FINE'
    ),
];
